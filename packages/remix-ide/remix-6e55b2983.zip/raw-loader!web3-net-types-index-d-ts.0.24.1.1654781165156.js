(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[42],{

/***/ 2919:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/*\n    This file is part of web3.js.\n    web3.js is free software: you can redistribute it and/or modify\n    it under the terms of the GNU Lesser General Public License as published by\n    the Free Software Foundation, either version 3 of the License, or\n    (at your option) any later version.\n    web3.js is distributed in the hope that it will be useful,\n    but WITHOUT ANY WARRANTY; without even the implied warranty of\n    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n    GNU Lesser General Public License for more details.\n    You should have received a copy of the GNU Lesser General Public License\n    along with web3.js.  If not, see <http://www.gnu.org/licenses/>.\n*/\n/**\n * @file index.d.ts\n * @author Josh Stevens <joshstevens19@hotmail.co.uk>\n * @date 2018\n */\n\nimport { NetworkBase } from 'web3-core';\n\nexport class Network extends NetworkBase {}\n");

/***/ })

}]);
//# sourceMappingURL=raw-loader!web3-net-types-index-d-ts.0.24.1.1654781165156.js.map
//# sourceMappingURL=raw-loader!web3-net-types-index-d-ts.0.24.1.1654781165156.js.map